local ADDON_TITLE = "DRKalenderPopup"
local GUILD_NAME = "Darkness Rising"
local LOGO_PATH = "Interface\\AddOns\\DRKalenderPopup\\logo.tga"

DRKalenderPopupDB = DRKalenderPopupDB or {}
DRKalenderPopupDB.pendingEventIDs = DRKalenderPopupDB.pendingEventIDs or {}
DRKalenderPopupDB.knownEventIDs = DRKalenderPopupDB.knownEventIDs or {}

local addon = CreateFrame("Frame")
addon.scanToken = 0
addon.currentPopupEventID = nil
addon.currentPopupTitle = nil
addon.currentPopupDate = nil
addon.popupVisibleForEventID = nil
addon.scanSchedule = { 2, 5, 9, 14, 20 }

local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(string.format("|cff7b68ee%s|r: %s", ADDON_TITLE, msg))
    end
end

local popup = CreateFrame("Frame", "DRKalenderPopupFrame", UIParent, "BackdropTemplate")
popup:SetSize(500, 280)
popup:SetPoint("CENTER")
popup:SetFrameStrata("DIALOG")
popup:SetFrameLevel(100)
popup:SetMovable(true)
popup:EnableMouse(true)
popup:RegisterForDrag("LeftButton")
popup:SetScript("OnDragStart", popup.StartMoving)
popup:SetScript("OnDragStop", popup.StopMovingOrSizing)
popup:Hide()

popup:SetBackdrop({
    bgFile = "Interface/DialogFrame/UI-DialogBox-Background-Dark",
    edgeFile = "Interface/DialogFrame/UI-DialogBox-Border",
    tile = true,
    tileSize = 32,
    edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
})
popup:SetBackdropColor(0, 0, 0, 0.95)

popup.title = popup:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
popup.title:SetPoint("TOP", 0, -18)
popup.title:SetText(GUILD_NAME)

popup.subtitle = popup:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
popup.subtitle:SetPoint("TOP", popup.title, "BOTTOM", 0, -8)
popup.subtitle:SetText("Gildenereignis steht aus")
popup.subtitle:SetTextColor(1, 0.82, 0, 1)

popup.logo = popup:CreateTexture(nil, "ARTWORK")
popup.logo:SetSize(128, 128)
popup.logo:SetPoint("TOPLEFT", 24, -64)
popup.logo:SetTexture(LOGO_PATH)

popup.message = popup:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
popup.message:SetPoint("TOPLEFT", popup.logo, "TOPRIGHT", 20, -4)
popup.message:SetPoint("RIGHT", -28, 0)
popup.message:SetJustifyH("LEFT")
popup.message:SetJustifyV("TOP")
popup.message:SetWordWrap(true)
popup.message:SetSpacing(4)

popup.okButton = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
popup.okButton:SetSize(140, 28)
popup.okButton:SetPoint("BOTTOMRIGHT", -82, 24)
popup.okButton:SetText("OK")

popup.closeButton = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
popup.closeButton:SetSize(140, 28)
popup.closeButton:SetPoint("RIGHT", popup.okButton, "LEFT", -12, 0)
popup.closeButton:SetText("Später")

local function EnsureCalendarLoaded()
    if not CalendarFrame then
        C_AddOns.LoadAddOn("Blizzard_Calendar")
    end
end

local function OpenCalendarWindow()
    EnsureCalendarLoaded()

    if Calendar_Toggle then
        Calendar_Toggle()
    elseif C_Calendar and C_Calendar.OpenCalendar then
        C_Calendar.OpenCalendar()
    else
        Print("Die Kalenderoberfläche konnte nicht geöffnet werden.")
    end
end

local function BuildDateText(info)
    if not info then
        return nil
    end

    local y = tonumber(info.year or 0) or 0
    local m = tonumber(info.month or 0) or 0
    local d = tonumber(info.monthDay or 0) or 0
    local hh = tonumber(info.hour or 0) or 0
    local mm = tonumber(info.minute or 0) or 0

    if y > 0 and m > 0 and d > 0 then
        return string.format("Datum: %02d.%02d.%04d um %02d:%02d Uhr", d, m, y, hh, mm)
    end

    return "Datum im Kalender ansehen"
end

local function SetPopupText(title, dateText)
    local body = string.format(
        "Für |cff7b68ee%s|r steht noch ein Gildenereignis im Kalender aus.\n\n|cffffffff%s|r\n%s\n\nKlicke auf |cff00ff00OK|r, um den Kalender zu öffnen.",
        GUILD_NAME,
        title or "Gildenereignis",
        dateText or "Datum im Kalender ansehen"
    )
    popup.message:SetText(body)
end

local function ShowPopupForEvent(eventID, title, dateText)
    if popup:IsShown() and addon.popupVisibleForEventID == eventID then
        return
    end

    addon.currentPopupEventID = eventID
    addon.currentPopupTitle = title
    addon.currentPopupDate = dateText
    addon.popupVisibleForEventID = eventID

    if popup.logo:GetTexture() == nil then
        popup.logo:SetColorTexture(0.35, 0.35, 0.35, 1)
    end

    SetPopupText(title, dateText)
    popup:Show()

    if PlaySound and SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPEN then
        PlaySound(SOUNDKIT.IG_MAINMENU_OPEN)
    end
end

popup.closeButton:SetScript("OnClick", function()
    addon.scanToken = addon.scanToken + 1
    addon.popupVisibleForEventID = nil
    popup:Hide()
end)

popup.okButton:SetScript("OnClick", function()
    local eventID = addon.currentPopupEventID
    addon.scanToken = addon.scanToken + 1
    addon.popupVisibleForEventID = nil
    if eventID then
        DRKalenderPopupDB.pendingEventIDs[eventID] = nil
    end
    popup:Hide()
    OpenCalendarWindow()
end)

local function GetFirstPendingEventInfo(foundEvents)
    for _, event in ipairs(foundEvents) do
        if DRKalenderPopupDB.pendingEventIDs[event.eventID] then
            return event
        end
    end
    return nil
end

local function ScanGuildEvents()
    EnsureCalendarLoaded()

    if not (C_Calendar and C_Calendar.GetNumGuildEvents and C_Calendar.GetGuildEventInfo) then
        return false, false
    end

    local numGuildEvents = tonumber(C_Calendar.GetNumGuildEvents() or 0) or 0
    if numGuildEvents <= 0 then
        return false, false
    end

    local foundEvents = {}
    local foundAny = false

    for index = 1, numGuildEvents do
        local info = C_Calendar.GetGuildEventInfo(index)
        if info and info.eventID then
            foundAny = true
            local eventID = tostring(info.eventID)
            local title = info.title or info.eventName or "Unbenanntes Gildenereignis"
            local dateText = BuildDateText(info)

            table.insert(foundEvents, {
                eventID = eventID,
                title = title,
                dateText = dateText,
            })

            if not DRKalenderPopupDB.knownEventIDs[eventID] then
                DRKalenderPopupDB.knownEventIDs[eventID] = true
                DRKalenderPopupDB.pendingEventIDs[eventID] = {
                    title = title,
                    dateText = dateText,
                }
            else
                local pending = DRKalenderPopupDB.pendingEventIDs[eventID]
                if pending then
                    pending.title = title
                    pending.dateText = dateText
                end
            end
        end
    end

    local pendingEvent = GetFirstPendingEventInfo(foundEvents)
    if pendingEvent then
        ShowPopupForEvent(pendingEvent.eventID, pendingEvent.title, pendingEvent.dateText)
        return true, foundAny
    end

    for eventID, data in pairs(DRKalenderPopupDB.pendingEventIDs) do
        if type(data) == "table" then
            ShowPopupForEvent(eventID, data.title, data.dateText)
            return true, foundAny
        end
    end

    return false, foundAny
end

local function StartLoginScanCycle()
    addon.scanToken = addon.scanToken + 1
    local myToken = addon.scanToken

    local function runScan()
        if myToken ~= addon.scanToken then
            return
        end
        local shown = ScanGuildEvents()
        if shown then
            addon.scanToken = addon.scanToken + 1
        end
    end

    runScan()
    for _, delay in ipairs(addon.scanSchedule) do
        C_Timer.After(delay, runScan)
    end
end

SLASH_DRKALENDERPOPUP1 = "/drpopup"
SlashCmdList["DRKALENDERPOPUP"] = function(msg)
    msg = tostring(msg or ""):lower()

    if msg == "test" then
        ShowPopupForEvent("test-event", "Testereignis", "Datum: 15.03.2026 um 20:00 Uhr")
    elseif msg == "scan" then
        local shown, foundAny = ScanGuildEvents()
        if shown then
            Print("Ausstehendes Gildenereignis gefunden.")
        elseif foundAny then
            Print("Gildenereignisse gefunden, aber keines ist für das Addon mehr ausstehend.")
        else
            Print("Es wurden derzeit keine Gildenereignisse gefunden.")
        end
    elseif msg == "reset" then
        DRKalenderPopupDB.pendingEventIDs = {}
        for eventID in pairs(DRKalenderPopupDB.knownEventIDs) do
            DRKalenderPopupDB.pendingEventIDs[eventID] = { title = "Gildenereignis", dateText = "Datum im Kalender ansehen" }
        end
        Print("Alle bekannten Gildenereignisse wurden wieder als ausstehend markiert.")
    elseif msg == "clear" then
        DRKalenderPopupDB.pendingEventIDs = {}
        DRKalenderPopupDB.knownEventIDs = {}
        Print("Gespeicherte Ereignisse wurden vollständig gelöscht.")
    else
        Print("Befehle: /drpopup test, /drpopup scan, /drpopup reset, /drpopup clear")
    end
end

addon:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        StartLoginScanCycle()
    elseif event == "CALENDAR_UPDATE_GUILD_EVENTS" then
        C_Timer.After(1, ScanGuildEvents)
    end
end)

addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("CALENDAR_UPDATE_GUILD_EVENTS")
