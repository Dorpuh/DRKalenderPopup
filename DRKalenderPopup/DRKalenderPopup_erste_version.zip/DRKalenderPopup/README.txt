DRKalenderPopup
Autor: Abgedropst
Gilde: Darkness Rising

Funktion:
- Prüft nach dem Login auf neue Gildenereignisse im Kalender.
- Zeigt ein deutsches Popup mit Gildenlogo.
- Klick auf OK öffnet den Blizzard-Kalender.

Slash-Befehle:
/drpopup test   -> zeigt Test-Popup
/drpopup scan   -> startet erneute Kalendersuche
/drpopup reset  -> setzt gespeicherte Ereignis-IDs zurück
