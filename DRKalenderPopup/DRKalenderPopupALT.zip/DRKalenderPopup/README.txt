DRKalenderPopup
Autor: Abgedropst
Gilde: Darkness Rising

Buttons
Chatbefehle
Insallation
-------------------------------------------------------------
Buttons

<OK>

öffnet direkt den WoW-Kalender

markiert das Ereignis im Addon als bearbeitet

Das Popup erscheint danach nicht mehr bei zukünftigen Logins für dieses Event.

<Später>

schließt das Fenster nur für den aktuellen Login

beim nächsten Login erscheint das Popup erneut
-------------------------------------------------------------
2. Chatbefehle

Das Addon enthält einige Debug- und Testbefehle.

Test-Popup anzeigen
/drpopup test
Zeigt das Popup sofort an.

Kalender manuell prüfen
/drpopup scan
Startet eine neue Suche nach Gildenereignissen.

Ereignisse erneut als offen markieren
/drpopup reset
Markiert bekannte Ereignisse wieder als offen.

Gespeicherte Daten löschen
/drpopup clear
Löscht alle gespeicherten Ereignisse aus dem Addon.
-----------------------------------------------------------
3. Installation

ZIP-Datei entpacken

Ordner DRKalenderPopup kopieren nach

World of Warcraft/_retail_/Interface/AddOns/

Spiel starten oder /reload
